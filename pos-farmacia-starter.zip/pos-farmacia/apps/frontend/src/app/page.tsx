export default function Home() {
  return (
    <main style={{padding: 24, fontFamily: 'ui-sans-serif, system-ui'}}>
      <h1 style={{fontSize: 28, marginBottom: 12}}>POS Farmacia</h1>
      <p>Frontend listo. Configura NEXT_PUBLIC_API_URL en el contenedor y navega a <code>/pos</code> cuando esté implementado.</p>
    </main>
  );
}
